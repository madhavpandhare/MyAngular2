import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IndexComponent } from './index/index.component';
import { AngularServicesComponent } from './index/angular-services/angular-services.component';
import { AngularFormsComponent } from './index/angular-forms/angular-forms.component';
import { AngularAnimationComponent } from './index/angular-animation/angular-animation.component';
import { AngularComponentsComponent } from './index/angular-components/angular-components.component';
import { AngularRoutingComponent } from './index/angular-routing/angular-routing.component';
import { AngularObservablesComponent } from './index/angular-observables/angular-observables.component';

const routes: Routes = [
  { path:'', component:IndexComponent },
  { path:'services', component:AngularServicesComponent },
  { path:'angularforms', component:AngularFormsComponent },
  { path:'animate', component:AngularAnimationComponent },
  { path:'angularcomponents', component:AngularComponentsComponent},
  { path:'routing', component:AngularRoutingComponent},
  { path:'Jsonserver', component:AngularObservablesComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
