import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User, Tableuser } from '../interfaces/user';

@Injectable({
  providedIn: 'root'
})
export class TableService {

  private baseURL = "https://reqres.in/api/users";
  private tableURL = "http://localhost:3000/travellingData/";
  constructor(private httpData:HttpClient) { }

  gettableData(): Observable<User>{
    return this.httpData.get<User>(this.tableURL);
  }
  setTableData(users):Observable<User>{
    return this.httpData.post<User>(this.tableURL, users)
  }
  deleteTableData(id){
    return this.httpData.delete(this.tableURL+id);
  }
}
