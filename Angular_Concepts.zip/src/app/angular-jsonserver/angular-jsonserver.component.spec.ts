import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AngularJSONServerComponent } from './angular-jsonserver.component';

describe('AngularJSONServerComponent', () => {
  let component: AngularJSONServerComponent;
  let fixture: ComponentFixture<AngularJSONServerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AngularJSONServerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AngularJSONServerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
