import { Component, OnInit } from '@angular/core';
import { TableService } from 'src/app/shared/services/table.service';

@Component({
  selector: 'app-angular-observables',
  templateUrl: './angular-observables.component.html',
  styleUrls: ['./angular-observables.component.css']
})
export class AngularObservablesComponent implements OnInit {

  tabData;

  constructor(private tabService: TableService) {
  }
  ngOnInit() {
    this.fetchData();
  }
  fetchData() {
    this.tabService.gettableData()
      .subscribe(
        res => {
          this.tabData = res;
        }
      )
  }
  onSubmit(items) {
    let users = {
      id: items.id,
      name: items.name,
      city: items.city,
      email: items.email,
      mobileNo: items.mobileNo,
    }
    console.log(users);
    this.tabService.setTableData(users)
      .subscribe(
        (res) => {
          // items = res;
          // console.log(items);
          this.fetchData();
        }

      )
  }
  deleteDatabyObservable(deleteItem){
    if(confirm( "Are You sure you want to Delete?")){
      this.tabService.deleteTableData(deleteItem)
      .subscribe(
        ()=>{
          this.fetchData();
        }
      );
      
    } 
   

  }
  deleteDatabyPromise(deleteItem){
    if(confirm( "Are You sure you want to Delete?")){
      this.tabService.deleteTableData(deleteItem)
      .toPromise().then(
        ()=>{
          this.fetchData();
        }
      );
    } 
   

  }
}
