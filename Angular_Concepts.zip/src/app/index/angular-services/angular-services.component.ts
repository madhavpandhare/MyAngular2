import { Component, OnInit } from '@angular/core';
import { TableService } from 'src/app/shared/services/table.service';

@Component({
  selector: 'app-angular-services',
  templateUrl: './angular-services.component.html',
  styleUrls: ['./angular-services.component.css']
})
export class AngularServicesComponent implements OnInit {

  public tableResult;
  tabData = [];
  loader:boolean = true;
  checked:boolean = false;
  constructor(private tabService: TableService) { }

  ngOnInit() {
    this.tabService.gettableData()
      .subscribe(
        responce => {
          this.tableResult = responce;
          this.tabData = this.tableResult.data;
          this.loader = false;
          this.checked = true;
        }
      ) 
  }

}
