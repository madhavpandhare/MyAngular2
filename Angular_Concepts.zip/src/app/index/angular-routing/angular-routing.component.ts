import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-routing',
  templateUrl: './angular-routing.component.html',
  styleUrls: ['./angular-routing.component.css']
})
export class AngularRoutingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
