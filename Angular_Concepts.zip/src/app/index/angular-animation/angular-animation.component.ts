import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-animation',
  templateUrl: './angular-animation.component.html',
  styleUrls: ['./angular-animation.component.css']
})
export class AngularAnimationComponent implements OnInit {

  toState = 'state1';
  constructor() { }

  changeState(state:any){
    this.toState = state;
  }

  ngOnInit() {
  }

}
