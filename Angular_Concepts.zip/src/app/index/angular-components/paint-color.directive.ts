import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appPaintColor]'
})
export class PaintColorDirective {

  constructor(private el:ElementRef) {
    el.nativeElement.style.backgroundColor = 'green';
   }

}
