import { PaintColorDirective } from './paint-color.directive';

describe('PaintColorDirective', () => {
  it('should create an instance', () => {
    const directive = new PaintColorDirective();
    expect(directive).toBeTruthy();
  });
});
