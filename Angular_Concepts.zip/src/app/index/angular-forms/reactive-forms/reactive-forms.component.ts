import { Component, OnInit } from '@angular/core';

import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'reactive-forms',
  templateUrl: './reactive-forms.component.html',
  styleUrls: ['./reactive-forms.component.css']
})
export class ReactiveFormsComponent implements OnInit {

 //avoid to repeat the code use FormBuilder ..
  // registrationForm = new FormGroup({
  //   username: new FormControl('Maddy'),
  //   password: new FormControl(''),
  //   confirmPassword: new FormControl(''),
  //   address: new FormGroup({
  //     city: new FormControl(''),
  //     state: new FormControl(''),
  //     postalCode: new FormControl('')
  //   })
  // });
  registrationForm : FormGroup

  get email(){
    return this.registrationForm.get('email');
  }
  constructor(private fb : FormBuilder) { }

  ngOnInit(){
    this.registrationForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      password:[''],
      email: [''],
      subscribe: [false],
      confirmPassword: [''],
      address: this.fb.group({
        city: [''],
        state: [''],
        postalCode: ['']
      })
    })
    this.registrationForm.get('subscribe').valueChanges
      .subscribe(checkedValue => {
        const email = this.registrationForm.get('email');
        if(checkedValue){
          email.setValidators(Validators.required)
        }else{
          email.clearValidators();
        }
        email.updateValueAndValidity();
      })
  }

  


  // loadAPIData(){
  //   this.registrationForm.setValue({
  //     username:'maddy',
  //     password:'mad123',
  //     confirmPassword:'mad123',
  //     address:{
  //       city:'Mumbai',
  //       state:'MH',
  //       postalCode:'123456'
  //     }
  //   })
  // }

}
