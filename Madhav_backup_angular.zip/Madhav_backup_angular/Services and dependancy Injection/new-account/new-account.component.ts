import { Component, OnInit} from '@angular/core';
import { LoggingService } from 'app/logging.service';

import { AccountsService } from '../accounts.service'


@Component({
  selector: 'app-new-account',
  templateUrl: './new-account.component.html',
  styleUrls: ['./new-account.component.css']
})
export class NewAccountComponent {

  constructor(private loggingService:LoggingService,
      private accountService: AccountsService){}

  onCreateAccount(accountName: string,  accountStatus: string){

    this.accountService.addAccount(accountName, accountStatus);
    //alert(accountStatus);
    // this.loggingService.logStatusChange(accountStatus);

    // const service = new LoggingService();
    // service.logStatusChange(accountStatus);
    // console.log('A server status changed and new status: ' +accountStatus);
  }
 
}
