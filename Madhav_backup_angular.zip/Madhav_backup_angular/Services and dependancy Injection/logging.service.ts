export class LoggingService{
    logStatusChange(status: string){
    console.log('A server status changed and new status: ' +status);
    }
    
}