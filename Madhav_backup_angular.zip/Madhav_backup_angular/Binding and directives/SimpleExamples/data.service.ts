import { Injectable } from '@angular/core';

@Injectable()


export class DataService {

  constructor() { }


  cars = ['ford','audi','maruti'];
  car = this.cars[0];

  myData(){
    return 'This is my data';
  }
}
