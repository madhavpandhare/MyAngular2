import { Component, OnInit } from '@angular/core';

import{ DataService } from './data.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  accounts:{name:string, status:string}[]=[];

  constructor(private dataService: DataService){

  }

  title :string;
  
  cars = ['ford','audi','maruti'];
  car = this.cars[0];

  heroes = ['windstrom','vampire','success'];
  myHero = this.heroes[0];

  example1:string = "";
  ngOnInit(){
    console.log(this.dataService.cars);
    this.title =  "Tour of heros";
    this.example1 = this.dataService.myData(); 
  }
}
