import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[appUnless]'
})
export class UnlessDirective {

  @Input() set appUnless(condition:boolean){
    if(!condition){
      this.vcRef.createEmbeddedView(this.tpRef);

    }else{
      this.vcRef.clear();

    }
  }

  constructor(private tpRef:TemplateRef<any>, private vcRef: ViewContainerRef) { }

}
