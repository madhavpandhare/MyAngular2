import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ViewChild } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

  servers= [
      {
        instanceType: 'medium',
        name: 'Production Server',
        status: 'stable',
        started: new Date(16,2,2018)
      },
      {
        instanceType: 'large',
        name: 'User',
        status:'stable',
        started: new Date(16,2,2018)
      },
      {
        instanceType: 'small',
        name: 'Development Server',
        status: 'offline',
        started: new Date(16,2,2018)
      },
      {
        instanceType: 'small',
        name: 'Testing Server',
        status:'stable',
        started: new Date(16,2,2018)
      }
  ];

  filteredStatus = "";
  getStatusClasses( server: {instanceType:string, name: string, status:string, started:Date })
  {
    return{
      'list-group-item-success':server.status === 'stable',
      'list-group-item-warning':server.status === 'offline',
      'list-group-item-danger' : server.status === 'critical'

    };
  }
 
constructor() {}

}

// items = ['JavaScript','Angular','ReactJS'];
  // newItem= "";

  // addItems = function(){
  //   if(this.newItem !== ""){
  //     this.items.push(this.newItem);
  //     //this.newItem ="";
  //     console.log("Record Added Sucessfully");
  //       }else{
  //         alert("Please Input something");
  //       }
  // }
  // removeItem =function(i){
  //   this.items.splice(i,1);
  //   console.log("Record Deleted Sucessfully");
  // }

  