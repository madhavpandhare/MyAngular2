import { Component, OnInit, style, transition, animate, keyframes  } from '@angular/core';
import { trigger, state, group } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [
    trigger('divState',[
        state('normal', style({
          'background-color': 'red',
          transform: 'translateX(0)'
        })),
        state('highlighted', style({
          'background-color': 'blue',
          transform: 'translateX(100px)'
        })),
        transition('normal <=> highlighted', animate(800)),
        //transition('highlighted => normal', animate(800))
    ]),
    //copied trigger
    trigger('wildState',[
      state('normal', style({
        'background-color': 'red',
        transform: 'translateX(0px) scale(1)'
      })),
      state('highlighted', style({
        'background-color': 'blue',
        transform: 'translateX(100px) scale(1)'
      })),
      state('shrunken', style({
        'background-color': 'green',
        transform: 'translateX(0px) scale(0.5)'
      })),
      transition('normal => highlighted', animate(500)),
      transition('highlighted => normal', animate(800)),
      transition('shrunken <=> *', [
        style({
          'background-color': 'orange'
        }),
        animate(1000, style({
          borderRadius: '50px'
        })),
        animate(500),
      ])
  ]),
  //copy trigger2
  trigger('list1',[
    state('in', style({
      opacity:1,
      transform: 'translateX(0)'
    })),
    state('highlighted', style({
      'background-color': 'blue',
      transform: 'translateX(100px)'
    })),
    transition('void => *', [
     style({
       opacity:0,
       transform: 'translateX(-100px)'
     }) , animate(800)]),
     transition('* => void', [
      animate(800, style({
        transform:'translateX(100px)',
        opacity: 0
      }))]),
   ]),

   // Copy trigger3

   trigger('list2',[
    state('in', style({
      opacity:1,
      transform: 'translateX(0)'
    })),
    state('highlighted', style({
      'background-color': 'blue',
      transform: 'translateX(100px)'
    })),
    transition('void => *', [
      animate(1000, keyframes([
        style({
          transform:'translate(-100px)',
          opacity:0,
          offset:0
        }),
        style({
          transform: 'translateX(-50px)',
          opacity: 0.5,
          offset:0.3
        }),
        style({
          transform: 'translateX(-20px)',
          opacity: 1,
          offset:0.8
        }),
        style({
          transform: 'translateX(0px)',
          opacity: 1,
          offset:1
        }),
      ]))
    ]),
     transition('* => void', [
       group([
        animate(300, style({
          color:'red',
        })),
        animate(800, style({
          transform:'translateX(100px)',
          opacity: 0,
          
        }))
       ])
    
      
    ]),
   ]),

  ]

})

export class AppComponent{
  list=['Milk','Sugar','Bread'];
  state='normal';
  wildstate = 'normal';

  onAdd(item){
    this.list.push(item);
    
  }
  onDelete(item){
    this.list.splice(this.list.indexOf(item),1);
    
  }

  onAnimate(){
    this.state == 'normal' ? this.state = 'highlighted' : this.state = 'normal';
    this.wildstate == 'normal' ? this.wildstate = 'highlighted' : this.wildstate = 'normal';
  }
  onShrink(){
    this.wildstate = 'shrunken';
  }

  animationStarted(event){
    console.log(event);

  }
  animationEnded(event){
    console.log(event);
  }

}







  // items = ['JavaScript','Angular','ReactJS'];
  // newItem= "";

  // addItems = function(){
  //   if(this.newItem !== ""){
  //     this.items.push(this.newItem);
  //     //this.newItem ="";
  //     console.log("Record Added Sucessfully");
  //       }else{
  //         alert("Please Input something");
  //       }
  // }
  // removeItem =function(i){
  //   this.items.splice(i,1);
  //   console.log("Record Deleted Sucessfully");
  // }
