import { Component } from '@angular/core';

@Component({
    selector:'app-warning-alert',
    template:`
    <p>This is warning please be safe</p>`,
    styles:[
        `
        p{
            padding:20px;
        background-color: #f1f1f1;
        border: 1px solid red;
        } `
    ]

})

export class WarningAlertComponent{

}