import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule} from '@angular/forms'
import { Routes, RouterModule } from '@angular/router';
import { ServerService } from 'app/server.service';



@NgModule({
  declarations: [
    AppComponent,
    
  ],
  imports: [
    BrowserModule,
    HttpModule,
    CommonModule,
    ReactiveFormsModule
   
  ],
  providers: [ServerService],
  bootstrap: [AppComponent],
})
export class AppModule { }