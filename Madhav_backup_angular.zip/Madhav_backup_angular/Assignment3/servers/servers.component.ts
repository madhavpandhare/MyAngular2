import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.css']
})
export class ServersComponent implements OnInit {
  allownewserver = false;
  serverCreation = "server not created please click";
  servername = "";
   sername2 = "";
  s_name="";
  sur_name= "";
  serverCreated = false;
  servers = ['testserver', 'testserver 2'];

  assignment_var="";
  constructor() {
    setTimeout(() =>{this.allownewserver= true;
    }, 2000);

    // setTimeout(()=>{this.secondbutton = true;},2000);
   }
  
  ngOnInit() {
  }

  onCreateServer(){
    this.serverCreation = "Server is created and name is " + this.servername;
    this.s_name = this.servername;
    this.sur_name = this.sername2;
    this.serverCreated=true;
    this.servers.push(this.servername);
  
  }
  onUpdateServerEvent(event: Event){
    // console.log(event);
    this.servername = (<HTMLInputElement>event.target).value;

  }
  oninputevent(evnet: Event){
    this.assignment_var = (<HTMLInputElement>event.target).value;

  }

}
