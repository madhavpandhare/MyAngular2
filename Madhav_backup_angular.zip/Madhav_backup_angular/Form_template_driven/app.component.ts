import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ViewChild } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  @ViewChild('f') signupForm: NgForm;
  defaultQuestion = "teacher";
  answer="";
  genders=['male','female'];

  user = {
    username:'',
    email : '',
    secretQuestion: '',
    answer : '',
    gender: ''
  };
  submitted = false;


  // items = ['JavaScript','Angular','ReactJS'];
  // newItem= "";

  // addItems = function(){
  //   if(this.newItem !== ""){
  //     this.items.push(this.newItem);
  //     //this.newItem ="";
  //     console.log("Record Added Sucessfully");
  //       }else{
  //         alert("Please Input something");
  //       }
  // }
  // removeItem =function(i){
  //   this.items.splice(i,1);
  //   console.log("Record Deleted Sucessfully");
  // }

  suggestUserName(){
    const suggestedName = 'SuperUser';
    this.signupForm.setValue({
      userData: {
        username: suggestedName,
        email: ''
      },
      secret: 'pet',
      questionAnswer: '',
      gender:'male'

    });
  }

  onSubmit(){
    this.submitted = true;
    this.user.username = this.signupForm.value.userData.username;
    this.user.email = this.signupForm.value.userData.email;
    this.user.secretQuestion = this.signupForm.value.secret;
    this.user.answer = this.signupForm.value.questionAnswer;
    this.user.gender = this.signupForm.value.gender;
    this.signupForm.reset();
  }
  ngOnInit(){}
}
