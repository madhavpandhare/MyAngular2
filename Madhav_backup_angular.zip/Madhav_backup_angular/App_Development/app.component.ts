import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  // title = 'Status to be changed!';
  // name="";
  // name1 = "yatin";
  // dissecreat = false;
  // log = [];

//   onToggle(){
//   this.dissecreat = !this.dissecreat;
//   this.log.push(this.log.length + 1);
// }

loadedFeature='recipe';
  onNavigate(feature:string){
    this.loadedFeature = feature;

  }
}
