import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.css']
})
export class ServersComponent implements OnInit {
  allownewserver = false;
  serverCreation = "server not created please click";
  servername = "";
  sername2 = "";
  s_name="";
  sur_name= "";

  secondbutton = false;

  assignment_var="";
  constructor() {
    setTimeout(() =>{this.allownewserver= true;
    }, 2000);

    setTimeout(()=>{this.secondbutton = true;},2000);
   }
  
  ngOnInit() {
  }

  onCreateServer(){
    this.serverCreation = "Server is created and name is " + this.servername;
    this.s_name = this.servername;
    this.sur_name = this.sername2;
  
  }
  onUpdateServerEvent(event: Event){
    // console.log(event);
    this.servername = (<HTMLInputElement>event.target).value;

  }
  oninputevent(evnet: Event){
    this.assignment_var = (<HTMLInputElement>event.target).value;

  }

}
