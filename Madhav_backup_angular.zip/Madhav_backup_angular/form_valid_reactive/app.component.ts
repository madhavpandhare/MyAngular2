import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ViewChild } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {

 genders=['male','female'];
 signupForm: FormGroup;
  
  ngOnInit(){
    this.signupForm = new FormGroup({
      'username': new FormControl('', Validators.required),
      'password': new FormControl('', [Validators.required, Validators.minLength(8)]),
      'email': new FormControl('', [Validators.required,Validators.pattern("[^ @]*@[^ @]*")]),
      'gender': new FormControl('male', Validators.required),
    });
  }

  onSubmit(){
    console.log(this.signupForm);
  }
}









  // items = ['JavaScript','Angular','ReactJS'];
  // newItem= "";

  // addItems = function(){
  //   if(this.newItem !== ""){
  //     this.items.push(this.newItem);
  //     //this.newItem ="";
  //     console.log("Record Added Sucessfully");
  //       }else{
  //         alert("Please Input something");
  //       }
  // }
  // removeItem =function(i){
  //   this.items.splice(i,1);
  //   console.log("Record Deleted Sucessfully");
  // }
