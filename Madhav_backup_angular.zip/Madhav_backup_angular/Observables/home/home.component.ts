import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';
import { setTimeout } from 'timers';
import {Observer} from 'rxjs/Observer';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy{

  numbersObSubscription: Subscription;
  customObSubscription: Subscription;

  constructor(private router:Router) { }

  ngOnInit() {
    const Numbers = Observable.interval(1000);
    this.numbersObSubscription = Numbers.subscribe(
      (number:number) =>{
        console.log(number);
      }
    )

  const myObeservable = Observable.create((observer: Observer<string>) =>{
    setTimeout(()=>{
      observer.next('first package');
    },2000);
  
    setTimeout(()=>{
      observer.next('second package');
    },4000);

    setTimeout(()=>{
      // observer.error('This does Not works');
      observer.complete();
    },5000);

    setTimeout(()=>{
      observer.next('Third Package');
    },6000);
  });
  this.customObSubscription = myObeservable.subscribe(
    (data:string) => {console.log(data);}
  );
  }
  ngOnDestroy(){
    this.numbersObSubscription.unsubscribe();
    this.customObSubscription.unsubscribe();
  }
 
}
