import { Component, OnInit } from '@angular/core';
import { UsersService } from 'app/users.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  items = ['abc','lmn','xyz'];
  newItem= "";

  addItems = function(){
    if(this.newItem !== ""){
      this.items.push(this.newItem);
      //this.newItem ="";
      console.log("Record Added Sucessfully");
      //console.log(items.length);
      this.newItem = '';
        }else{
          alert("Please Input something");
        }
  }
  removeItem =function(i){
    this.items.splice(i,1);
    console.log("Record Deleted Sucessfully");
  }

  ngOnInit(){}
}
