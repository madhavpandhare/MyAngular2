import { Component } from '@angular/core';

import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';

import * as PostActions from '../app/post.actions'
import { Post }         from '../app/post.model'


// import 'rxjs/add/operator/take'; 
// import '@ngrx/core/add/operator/select';
// import 'rxjs/add/operator/let';

interface AppState{
  message : string;

  post:Post;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent{
  messages : Observable<string>
  post : Observable<Post>

  constructor(private store: Store<AppState>){
    this.messages = this.store.select('message');
    this.post = this.store.select('post');
  }
  spanishMessage(){
    
    this.store.dispatch({type : 'SPANISH'})
  }

  frenchMessage(){
    this.store.dispatch({type : 'FRENCH'})
  }

  text:string;

  editText(){
    this.store.dispatch(new PostActions.EditText(this.text))
  }
  resetPost(){
    this.store.dispatch(new PostActions.Reset)
  }
  upvote(){
    this.store.dispatch(new PostActions.Upvote())
  }

  downvote(){
    this.store.dispatch(new PostActions.Downvote())
  }

}
