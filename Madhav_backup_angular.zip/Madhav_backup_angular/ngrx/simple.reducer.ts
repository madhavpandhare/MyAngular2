import { Action } from '@ngrx/store';

export function simpleReducer(state: string ="Hi" , action:Action){
    console.log(action.type, state)

    switch(action.type){
        case 'SPANISH':
        return state = 'Hello Spanish'

        case "FRENCH":
        return state = 'Hello French'

        default:
        return state;
    }

}