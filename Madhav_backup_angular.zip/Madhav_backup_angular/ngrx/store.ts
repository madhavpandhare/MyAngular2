export interface IAppState{

}

export function rootReducer(state, action){
    return state;

}