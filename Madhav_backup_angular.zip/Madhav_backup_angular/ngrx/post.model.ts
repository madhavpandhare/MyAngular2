export interface Post{
    text: string;
    likes : number;
}