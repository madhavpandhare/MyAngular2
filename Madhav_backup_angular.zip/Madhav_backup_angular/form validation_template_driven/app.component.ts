import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ViewChild } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {

  @ViewChild('f') signupForm:NgForm
  defaultQuestion = "pet";
  genders=['Male','Female'];

  user= {
    username:'',
    password:'',
    email:'',
    secretQuestion:'',
    gender:''

  }
  submitted = false;

  onSubmit(){
    //console.log(this.signupForm);
    this.submitted=true;
    this.user.username = this.signupForm.value.username;
    this.user.password = this.signupForm.value.password;
    this.user.email = this.signupForm.value.email;
    this.user.secretQuestion = this.signupForm.value.secret;
    this.user.gender = this.signupForm.value.gender;
    this.signupForm.reset();
  }
  
  ngOnInit(){}
}









  // items = ['JavaScript','Angular','ReactJS'];
  // newItem= "";

  // addItems = function(){
  //   if(this.newItem !== ""){
  //     this.items.push(this.newItem);
  //     //this.newItem ="";
  //     console.log("Record Added Sucessfully");
  //       }else{
  //         alert("Please Input something");
  //       }
  // }
  // removeItem =function(i){
  //   this.items.splice(i,1);
  //   console.log("Record Deleted Sucessfully");
  // }
