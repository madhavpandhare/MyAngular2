export class User {
    Username : string;
    Password: string;
    
}
