import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { CommonModule } from '@angular/common';
import { SignupComponent } from './signup/signup.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RouterModule, Routes} from '@angular/router';
import { Component } from '@angular/core';


const appRoutes:Routes = [
  {
    path: '',
    component: SignupComponent
  },
  {
  path:'dashboard',
  component: DashboardComponent
  }
]

@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    DashboardComponent,
    
        
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    CommonModule,
    RouterModule.forRoot(appRoutes)
   
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule { }