import { Component, OnInit } from '@angular/core';
import { User } from 'app/shared/user.model';
import { NgForm } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { Validators } from '@angular/forms/src/validators';
import { PatternValidator } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  user : User;
  loginform : FormGroup;

  //passpattern = '^(0|[1-9][0-9]*)$';
  passpattern = '^(0|[1-9][0-9]*)$';
  namePattern = '^([a-z]*)'
  //passpattern = '/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]$/'

  constructor(private router:Router) { }

  ngOnInit() {
    this.resetForm();
    // this.loginform = new FormGroup({
    //   'Password': new FormControl('',Validators.required),
    //})
  }

  resetForm(form?:NgForm){
    if(form != null)
    form.reset();
    this.user = {
      Username: '',
      Password:''
    }
  }

  loginUser(e){
    var username = this.user.Username;
    var password = this.user.Password
    console.log(username, password);

    if(username == "admin" && password == "admin123"){
      this.router.navigate(['dashboard']);
    }

  }
}
