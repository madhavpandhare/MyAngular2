import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';


// const appRoutes: Routes = [
//     {path:'', component: HomeComponent},
//     {path:'user/:id', component:UserComponent}
// ]; 

@NgModule({
  declarations: [
    AppComponent,
    // HomeComponent,
    // UserComponent,
        
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpModule,
    FormsModule,
    CommonModule
    // RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule { }