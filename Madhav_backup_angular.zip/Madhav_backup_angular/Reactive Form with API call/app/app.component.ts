import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
//import { FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';

import { Http, Response } from '@angular/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  genders = ['male','female'];
  signupForm:FormGroup;
  public name:any;
  cName = '';
  // user = {
  //   username: '',
  //   email : '',
  //   gender : '',
  //   street : '',
  //   city : '',
  //   postalcode : ''
  // }

  //Using Form Builders

  constructor(private formbuilder: FormBuilder, private http:Http){}

      ngOnInit(){
        this.signupForm =this.formbuilder.group({
          username: [null, [Validators.required, Validators.minLength(4),Validators.maxLength(10)]],
          email: [null, [Validators.required, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')]],
          password: [null, [Validators.required]],
          gender: ['male'],
          cName: [null, Validators.required],
          address: this.formbuilder.group({
          street: [null, Validators.required],
          city:[null],
          postalcode: [null, Validators.pattern('^[1-9][0-9]{4}$')]
          }),
        
        });
      }

  submitted=false;


  // Without Form Builder

  // ngOnInit(){
  //   this.signupForm = new FormGroup({
  //     'username': new FormControl(null, [Validators.required, Validators.minLength(4),Validators.maxLength(15)]),
  //     'email': new FormControl('', [Validators.required]),
  //     'gender': new FormControl('male'),
  //     'address': new FormGroup({
  //     'street': new FormControl('', Validators.required),
  //     'city':new FormControl(null),
  //     'postalcode': new FormControl(null, Validators.pattern('^[1-9][0-9]{4}$'))
  //   })
  //   });
  // }

  onSubmit(){
    this.submitted = true;
    // this.user.username = this.signupForm.value.username;
    // this.user.email = this.signupForm.value.email;
    // this.user.gender = this.signupForm.value.gender;
    // this.user.street = this.signupForm.value.street;
    // this.user.city = this.signupForm.value.city;
    // this.user.postalcode = this.signupForm.value.postalcode;
    //console.log(this.signupForm.value);
    this.signupForm.reset();
  }

  searchCollege(e){
    let cName = this.signupForm.get('cName').value;
    
    //console.log('vcddaad',cName);
    // alert(cName)
          setTimeout(()=>this.http.get('http://admissiondesk.org/searchCollege?name=' + cName)
          .subscribe(
            (res:Response)=>{
              let Tname = res.json();
              this.name =Tname.data;
              //console.log(this.name);  
              console.log(cName);         
      }),200)   
  }

  // getValue(event){
  //   let sName = this.signupForm.setValue(this.cName);
  //  console.log("clicked on li" + sName);
  // }

  
  // searchCollegebyngModel(e){
  //   //let cName = this.signupForm.get('cName').value;
  //   //console.log('vcddaad',cName);
    
  //   // alert(cName)
  //         setTimeout(()=>this.http.get('http://admissiondesk.org/searchCollege?name=' + this.cName)
  //         .subscribe(
  //           (res:Response)=>{
  //             let Tname = res.json();
  //             this.name =Tname.data;
  //             console.log(this.name);           
  //     }),200)
  // }

  // onKey(event:any){
  //   this.http.get('http://admissiondesk.org/searchCollege?name=' + this.collegeName)
  //         .subscribe(
  //           (res:Response)=>{
  //             let Tname = res.json();
  //             this.name =Tname.data;
  //             console.log(this.name);           
  //     });

  // }
  
}
