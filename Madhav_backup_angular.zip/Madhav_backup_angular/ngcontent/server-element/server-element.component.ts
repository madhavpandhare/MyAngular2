import { Component, OnInit, Input, OnChanges,DoCheck} from '@angular/core';

@Component({
  selector: 'app-server-element',
  templateUrl: './server-element.component.html',
  styleUrls: ['./server-element.component.css']
})
export class ServerElementComponent implements OnInit, OnChanges, DoCheck {
 @Input('srvElement') element: {type:string, name:string, content:string};
 @Input() name:string;

  constructor() { 
    console.log("constructor called");
  }

  ngOnChanges(){
    console.log("ngOnChanges Called");
     
  }
  ngOnInit() {
    console.log("changes called");
  }
ngDoCheck(){
  console.log("ngDoCheck called");
}
}
