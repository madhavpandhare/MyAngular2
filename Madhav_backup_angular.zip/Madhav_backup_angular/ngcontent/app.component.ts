import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  // title = 'Status to be changed!';
  // name="";
  // name1 = "yatin";
  // dissecreat = false;
  // log = [];

//   onToggle(){
//   this.dissecreat = !this.dissecreat;
//   this.log.push(this.log.length + 1);
// }

// loadedFeature='recipe';
//   onNavigate(feature:string){
//     this.loadedFeature = feature;
//   }

serverElements = [{type:'server', name:'TestServer', content:'just a test'}];


onServerAdded(serverData:{serverName: string, serverContent:string}){
  this.serverElements.push({
    type: 'server',
    name: serverData.serverName,
    content: serverData.serverContent
  });
}
onBlueprintAdded(blueprintData:{serverName:string, serverContent:string}){
  this.serverElements.push({
    type:'server',
    name: blueprintData.serverName,
    content: blueprintData.serverContent
  });
}

onChangeFirst(){
  this.serverElements[0].name = 'Changed';
}
}
