import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { CockpitComponent } from './cockpit/cockpit.component';
import { ServerElementComponent } from './server-element/server-element.component';
// import { ServerComponent } from './server/server.component';
// import { ServersComponent } from './servers/servers.component';
// import { WarningAlertComponent} from './warning-alert/warning-alert.component';
// import { SucessAlertComponent } from './sucess-alert/sucess-alert.component';
// import { HeaderComponent } from './header/header.component';
// import { RecipesComponent } from './recipes/recipes.component';
// import { RecipesListComponent } from './recipes/recipes-list/recipes-list.component';
// import { RecipesDetailComponent } from './recipes/recipes-detail/recipes-detail.component';
// import { RecipesItemComponent } from './recipes/recipes-list/recipes-item/recipes-item.component';
// import { ShoplistComponent } from './shoplist/shoplist.component';
// import { ShoppingEditComponent } from './shoplist/shopping-edit/shopping-edit.component';





@NgModule({
  declarations: [
    AppComponent,
    CockpitComponent,
    ServerElementComponent,
    // ServerComponent,
    // ServersComponent
    // WarningAlertComponent,
    // SucessAlertComponent,
    // HeaderComponent,
    // RecipesComponent,
    // RecipesListComponent,
    // RecipesDetailComponent,
    // RecipesItemComponent,
    // ShoplistComponent,
    // ShoppingEditComponent,
    
    
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
