import { Component, OnInit,EventEmitter, Output,ViewChild,ElementRef} from '@angular/core';

@Component({
  selector: 'app-cockpit',
  templateUrl: './cockpit.component.html',
  styleUrls: ['./cockpit.component.css']
})
export class CockpitComponent implements OnInit {
  @Output() serverCreated = new EventEmitter<{serverName: string, serverContent:string}>();
  @Output() blueprintCreated = new EventEmitter<{serverName: string, serverContent:string}>();
  newServerName = '';
  newServerContent = '';
  @ViewChild('serverContentInput') serverContentInput:ElementRef;

  constructor() {
    
   }

  ngOnInit() {
    console.log("ngoninit called");
  }
  onAddServer(Input:HTMLInputElement){
    //console.log(Input.value);
    this.serverCreated.emit({
      serverName: Input.value, 
      serverContent: this.newServerContent
    });
  }

  onAddblueprint(){
    this.blueprintCreated.emit({
      serverName: this.newServerName, 
      // serverContent: this.serverContentInput.nativeElement.value
      serverContent: this.newServerContent
    });
  }

}
