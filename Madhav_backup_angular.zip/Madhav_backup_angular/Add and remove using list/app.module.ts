import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { UsersService } from './users.service'

// const appRoutes: Routes = [
//     {path:'', component: HomeComponent},
//     {path:'user/:id', component:UserComponent}
// ]; 

@NgModule({
  declarations: [
    AppComponent,
    // HomeComponent,
    // UserComponent,
        
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    CommonModule
    // RouterModule.forRoot(appRoutes)
  ],
  providers: [UsersService],
  bootstrap: [AppComponent],
})
export class AppModule { }