import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { IndexModule } from './index/index.module';
import { AngularFormsModule } from './index/angular-forms/angular-forms.module';
import { AngularJSONServerComponent } from './angular-jsonserver/angular-jsonserver.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent,
    AngularJSONServerComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    IndexModule,
    AngularFormsModule,
    HttpClientModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
