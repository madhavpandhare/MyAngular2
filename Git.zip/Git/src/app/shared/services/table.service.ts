import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../interfaces/user';

@Injectable({
  providedIn: 'root'
})
export class TableService {

  private baseURL = "https://reqres.in/api/users";
  constructor(private httpData:HttpClient) { }

  gettableData(): Observable<User>{
    return this.httpData.get<User>(this.baseURL)
  }
}
