import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-jsonserver',
  templateUrl: './angular-jsonserver.component.html',
  styleUrls: ['./angular-jsonserver.component.css']
})
export class AngularJSONServerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
