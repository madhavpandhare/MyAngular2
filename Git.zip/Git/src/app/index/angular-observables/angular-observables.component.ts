import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-observables',
  templateUrl: './angular-observables.component.html',
  styleUrls: ['./angular-observables.component.css']
})
export class AngularObservablesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
