import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-components',
  templateUrl: './angular-components.component.html',
  styleUrls: ['./angular-components.component.css']
})
export class AngularComponentsComponent implements OnInit {

  firstimgUrl = "assets/images/samplePhoto.jpg";
  firstName = "Image1";
  isImage :boolean = false;
  data:number = 100;
  userData = [
    {id:1, name:"ABC"},
    {id:2, name:"XYZ"}
  ]
  constructor() { 
    console.log(`new Constructor - data is ${this.data}`);
  }
  ngOnChanges(){
    console.log(`new ngOnChanges - data is ${this.data}`);
  }

  ngOnInit() {
    console.log(`ngOnInit - data is ${this.data}`);
  }
  ngDoCheck(){
    console.log(`ngDoCheck - data is ${this.data}`);
  }
  ngAfterContentInit(){
    console.log(`ngAfterContentInit - data is ${this.data}`);
  }
  ngAfterContentChecked(){
    console.log(`ngAfterContentInit - data is ${this.data}`);
  }
  ngAfterViewInit(){
    console.log(`ngAfterViewInit - data is ${this.data}`);
  }
  ngAfterViewChecked(){
    console.log(`ngAfterViewChecked - data is ${this.data}`);
  }
  ngDestroy(){
    console.log(`ngDestroy - data is ${this.data}`);
  }
  toggleImage(){
    this.isImage = !this.isImage; 
    if(this.isImage){
      this.firstimgUrl = "assets/images/samplePhoto2.jpg";
      this.firstName = "Image2";
    }else{
      this.firstimgUrl= "assets/images/samplePhoto.jpg";
      this.firstName = 'Image1';
    }
    
  }
  public items= [
    {id:1, name:"Apple", type:'fruit'},
    {id:2, name:"TURNIP", type:'veg'},
    {id:3, name:"ORANGE", type:'fruit'}
  ];

  public getBgColor(type){
    if(type === 'fruit'){
      return 'blue'
    }else{
      return 'green'
    }
  }
  addNumber():void{
    this.data +=100;
  }
  removeNumber():void{
    this.data -=100;
  }

}
