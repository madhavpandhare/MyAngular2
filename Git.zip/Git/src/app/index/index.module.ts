import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AngularServicesComponent } from './angular-services/angular-services.component';
import { AngularRoutingComponent } from './angular-routing/angular-routing.component';
import { AngularComponentsComponent } from './angular-components/angular-components.component';
import { AngularObservablesComponent } from './angular-observables/angular-observables.component';
import { AngularAnimationComponent } from './angular-animation/angular-animation.component';
import { IndexComponent } from './index.component';
import { RouterModule } from '@angular/router';
import { FormsRouting } from './angular-forms/angular-forms-routing.module';
import { AnimateComponent } from './angular-animation/animate/animate.component';
import { FormsModule } from '@angular/forms';
import { PaintColorDirective } from './angular-components/paint-color.directive';
import { BoardComponent } from './angular-routing/board/board.component';
import { SquareComponent } from './angular-routing/square/square.component';

@NgModule({
  declarations: [ AngularServicesComponent, 
                  AngularRoutingComponent,
                  AngularComponentsComponent, 
                  AngularObservablesComponent, 
                  AngularAnimationComponent, 
                  IndexComponent, AnimateComponent, PaintColorDirective, BoardComponent, SquareComponent],
  imports: [
    CommonModule,
    RouterModule,
    FormsRouting,
    FormsModule
  ],
  exports: [AngularServicesComponent,
            AngularRoutingComponent,
            AngularComponentsComponent,
            AngularObservablesComponent,
            AngularAnimationComponent,
            AnimateComponent]
})
export class IndexModule { }
