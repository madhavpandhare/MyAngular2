import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TemplateFormsComponent } from './template-forms/template-forms.component';
import { ReactiveFormsComponent } from './reactive-forms/reactive-forms.component';
import { AngularFormsComponent } from './angular-forms.component';
import { FormsRouting } from './angular-forms-routing.module';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [TemplateFormsComponent, ReactiveFormsComponent, AngularFormsComponent],
  imports: [
    CommonModule,
    FormsRouting,
    RouterModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports:[TemplateFormsComponent, ReactiveFormsComponent]
})
export class AngularFormsModule { }
