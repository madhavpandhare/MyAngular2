import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TemplateFormsComponent } from './template-forms/template-forms.component';
import { ReactiveFormsComponent } from './reactive-forms/reactive-forms.component';

const routes : Routes = [
    { path:'angularForms/templateForm', component:TemplateFormsComponent },
    { path:'angularForms/reactiveForm', component:ReactiveFormsComponent }
]

@NgModule({
    imports: [RouterModule.forRoot(routes)]
})

export class FormsRouting{}