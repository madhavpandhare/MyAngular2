import { Component, OnInit } from '@angular/core';
import { trigger, style, state, transition, animate, keyframes, query, stagger, } from '@angular/animations';

@Component({
  selector: 'app-animatedata',
  templateUrl: './animatedata.component.html',
  styleUrls: ['./animatedata.component.css'],
  animations:[
    trigger('photoState', [
      state('move', style({
        transform: 'translateX(70%) translateY(50px)',
      })),
      state('enlarge', style({
        transform: 'scale(1.5)',
      })),
      state('spin', style({
        transform: 'rotateY(180deg) rotateZ(90deg)'
      })),
      transition('spin => move', animate('5000ms ease-out')),
      transition('* => *', animate('2000ms ease'))
      
    ])
  ]
})
export class AnimatedataComponent implements OnInit {


  position : string;
  photoUrl = "https://pbs.twimg.com/profile_images/819995777829314561/P9rCZUzc_400x400.jpg";

  changePosition( newPostion: string){
    this.position = newPostion
  }
  constructor() { }
  ngOnInit() {
  }

}
