import { Injectable } from '@angular/core';

@Injectable()
export class CartserviceService {
  name=""
  public CartList;
  public totalArray;
  public sumtotal;

  constructor() { }
  

  getmovie(list){
    const abc =1;
    console.log(abc);
    console.log("Service");
    this.CartList.push(list.name);
    this.totalArray.push(list.price);
    this.sumtotal = this.totalArray.reduce((a, b) => a + b, 0);

    localStorage.setItem('temptot', this.sumtotal);
    localStorage.getItem('temptot');
  }

}
