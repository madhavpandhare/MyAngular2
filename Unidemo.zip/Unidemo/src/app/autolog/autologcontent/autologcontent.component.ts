import { Component, OnInit, OnDestroy } from '@angular/core';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-autologcontent',
  templateUrl: './autologcontent.component.html',
  styleUrls: ['./autologcontent.component.css']
})
export class AutologcontentComponent implements OnDestroy, OnInit {
  public idleState = 'Not started.';
  public timedOut = false;

  public idleEndCount = 0;
  public idleStartCount = 0;
  public idleTimeoutCount = 0;
  public idleTimeoutWarningCount = 0;
  public isIdle;

  constructor(private idle: Idle, private router: Router) {

    this.isIdle = false;

    this.idle.setIdle(5);
    this.idle.setTimeout(10);
    //this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    // idle.onIdleEnd.subscribe(() => {
    //   this.idleEndCount++;
    //   this.idleState = 'No longer idle.'
    // });

    idle.onTimeout.subscribe(() => {
      this.idleTimeoutCount++;
      this.idleState = 'Timed out!';
      this.timedOut = true;
      this.router.navigate(['/login']);
    });

    // idle.onIdleStart.subscribe(() => {
    //   this.idleStartCount++;
    //   this.idleState = 'You\'ve gone idle!'
    // });

    idle.onTimeoutWarning.subscribe((countdown) => {
      this.idleTimeoutWarningCount++;
      this.idleState = 'You will time out in ' + countdown + ' seconds!'
    });

    this.reset();

  }

  ngOnDestroy() {
    this.idle.stop();
  }

  reset() {
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
  }
  ngOnInit() { }
}
