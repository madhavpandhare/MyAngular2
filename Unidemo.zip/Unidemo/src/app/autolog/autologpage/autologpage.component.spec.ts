import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutologpageComponent } from './autologpage.component';

describe('AutologpageComponent', () => {
  let component: AutologpageComponent;
  let fixture: ComponentFixture<AutologpageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutologpageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutologpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
