import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-autologpage',
  templateUrl: './autologpage.component.html',
  styleUrls: ['./autologpage.component.css']
})
export class AutologpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
