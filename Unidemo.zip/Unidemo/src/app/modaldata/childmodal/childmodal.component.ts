import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-childmodal',
  templateUrl: './childmodal.component.html',
  styleUrls: ['./childmodal.component.css']
})
export class ChildmodalComponent implements OnInit {

  @Input() parentData : string;
  @Input() msg:string;
  @Output() childEvent;

  constructor() { 
    this.childEvent = new EventEmitter<string>();
  }
  onChange(value:string){
    this.childEvent.emit(value);
  }

  ngOnInit() {
  }

}
