import { Component, OnInit } from '@angular/core';
import { NgForm, FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-modaldata',
  templateUrl: './modaldata.component.html',
  styleUrls: ['./modaldata.component.css']
})
export class ModaldataComponent implements OnInit {

 public childData:string;
 msg = "Hello I came from parent"

  /* Solution For Table Update Data
  private fieldArray: Array<any> = [];
    private newAttribute: any = {};

    addFieldValue() {
      this.fieldArray.push(this.newAttribute)
      this.newAttribute = {};
  }

  deleteFieldValue(index) {
      this.fieldArray.splice(index, 1);
  }
  */

  public submitted = false;
  public modalView1 = true;
  fname = "";
  lname = "";
  mail = "";

  public arraydata: any = {};
  public olddata:any = {};
  public tabledata = [];

  constructor() { }
  createForm: FormGroup;

  displayData() {
    this.submitted = true;
    this.modalView1 = false;
    this.tabledata.push(this.arraydata);
    this.olddata = this.tabledata;
    this.arraydata = {};
    console.log(this.olddata);
  }

  flushData(i) {
    this.tabledata.splice(i, 1);
  }

  upData(event,i){
    this.olddata[i]= this.tabledata;
    console.log(i);    
  }
  // updatedData(i){
  //   this.olddata[i];
  // }

  ngOnInit() {
    this.createForm = new FormGroup({
      fname: new FormControl('', Validators.required),
      'lname': new FormControl('', Validators.required),
      'mail': new FormControl('', Validators.required)
    })
  }

}
