import { Component, OnInit,Pipe } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SortPipe } from '../dateformat/sort.pipe';

@Component({
  selector: 'app-dateformat',
  templateUrl: './dateformat.component.html',
  styleUrls: ['./dateformat.component.css'],
  providers:[SortPipe]
})
export class DateformatComponent implements OnInit {

  getdata = [];
  setvalue = "";
  displayme = false;

  addItem = function () {
    this.getdata.push(this.setvalue);
    this.setvalue = "";
    this.displayme = true;
  }
  removeitem = function () {
    this.getdata.splice(0, 1);
  }

  myForm: FormGroup;
  public myDatearray = [
    {
      'one': '01/02/2017',
      'fname': 'sam',
      'lname': 'kaliak'
    },
    {
      'one': '02/05/2015',
      'fname': 'kam',
      'lname': 'hjahsd'
    },
    {
      'one': '03/12/2015',
      'fname': 'jakha',
      'lname': 'Wahckre'
    }
  ];
  arraydate = [];
  stateArray = [];

  public autoData = [
    { 'id': 0, 'field': 'textarea', 'label': 'ABC', 'value': 'XYZ', 'require': '*' },
    { 'id': 1, 'field': 'textarea', 'label': 'LMN', 'value': 'KLA', 'require':'' },
    { 'id': 2, 'field': 'textarea', 'label': 'ASF', 'value': 'JAN', 'require': '*' }
  ];

  public dupData = [
    { 'id': 0, 'field': 'textarea', 'label': 'ABC', 'value': 'XYZ',},
    { 'id': 1, 'field': 'textarea', 'label': 'LMN', 'value': 'KLA',},
    { 'id': 2, 'field': 'textarea', 'label': 'ASF', 'value': 'JAN',}
  ];
  public newid;
  public requireArray = [];

  public sortindex;
  public optionData = [
    {'ids':3},{'ids':1},{'ids':2}
  ]

  options = [
    {
      measure: '3',
      display: '3',
      name:'DD'
    },
    {
      measure: '2',
      display: '2',
      name:'CC'
    },
    {
      measure: '1',
      display: '1',
      name:'BB'
    },
    {
      measure: '5',
      display: '5',
      name:'FF'
    },
    {
      measure: '4',
      display: '4',
      name:'EE'
    },
    {
      measure: '0',
      display: '0',
      name:'AA'
    },

];

check1 = false;
hideShow = false;

  sortme(i){
    this.sortindex = i;
    console.log(this.sortindex);
    //this.optionData = this.optionData.sort();
    console.log(this.dupData[i]);
     console.log(this.optionData);
  }
 
  constructor(private frombuild: FormBuilder) { }
  ngOnInit() {
    
    //console.log(this.myDatearray);
    for (let f1 of this.myDatearray) {
      this.arraydate.push(f1.one);
    }
    this.myForm = this.frombuild.group({
      textarea: [null, Validators.required],
      req: [null, Validators.required]
    })
  }
  remReq(i) {
    console.log('hi');
    if(this.check1 == false){
      this.hideShow = true;
    }else{
      console.log('elsae');
      this.hideShow = false;
    }

    
    // this.newid = i;
    // console.log(i);
    // console.log(this.newid);
    // this.hideShow = false;
    // let reqval = this.myForm.value.req;
    // console.log(reqval);

    // if(reqval !=true || this.newid == i){
    //   this.hideShow = false;
    //   this.stateArray.push(i);
    //   console.log(this.stateArray);
    // }    
  }
  sub(event) {
    console.log("clicked");
  }
}
