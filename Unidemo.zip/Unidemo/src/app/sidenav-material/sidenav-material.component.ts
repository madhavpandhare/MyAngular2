import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/map';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-sidenav-material',
  templateUrl: './sidenav-material.component.html',
  styleUrls: ['./sidenav-material.component.css']
})
export class SidenavMaterialComponent implements OnInit {

  myData:any =[];

  constructor(private http :HttpClient, private snackbar: MatSnackBar) { 
    this.http.get("https://jsonplaceholder.typicode.com/photos")
    .map(response => response)
    .subscribe(result => this.myData = result)
  }

  likeMe(i){
    if(this.myData[i].id == 1)
    this.myData[i].id =1;
    else
    this.myData[i].id = 0;

  }
  deleteMe(i){
    this.myData.splice(i,1);
    console.log(i);
  }
  openSnackBar(message: string, action: string){
    this.snackbar.open(message, action,{
      duration:2000
    });  

  }

  ngOnInit() {
  }

}
