import { Component, OnInit } from '@angular/core';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';

@Component({
  selector: 'app-postupload',
  templateUrl: './postupload.component.html',
  styleUrls: ['./postupload.component.css']
})
export class PostuploadComponent implements OnInit {

  apiroot : string = "http://httpbin.org";

  public getdata = '/get';
  public deldata = '/delete';
  public postdata = '/post';
  public putdata = '/put';

  public headerObj = {
    'Content-Type':'application/json',
    'Accept':'application/json',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Username':'ABCDEFG'
  }
 
  public requestOptions = {                                                                                                                                                                                 
    headers: new Headers(this.headerObj), 
  };

  constructor( private http : Http) { }
  doGET(){

     /* Header Data */
    const headerObj = {
      'Content-Type':'application/json',
      'Accept':'application/json',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Username':'ABCDEFG'
    }
   
    const requestOptions = {                                                                                                                                                                                 
      headers: new Headers(headerObj), 
    };
    
    /* ADD SearchParams */
    let search = new URLSearchParams();
    search.set('Smapledata','moo');
    search.set('limit','25');
    //this.http.get(this.apiroot + this.getdata).subscribe(res => console.log(res.text()));
    this.http.get(this.apiroot + this.getdata, requestOptions)
    .subscribe(res => console.log(res.json()));
  }

  doPOST(){

    const PostHeaderData = {
      'Authorization':'PostAuthorization',
      'Username':'Madhav@gmail.com',
      'Password':'M@dhav1234'
    }

    const postrequeOption = {
    headers : new Headers(PostHeaderData)
  }

    let search = new URLSearchParams();
    search.set('Smapledata','moo');
    search.set('limit','25');
    //this.http.get(this.apiroot + this.getdata).subscribe(res => console.log(res.text()));
    this.http.post(this.apiroot + this.postdata, 
      {search}, postrequeOption)
      .subscribe(res => console.log(res.json(), console.log(res.headers)));


  }
  doPUT(){

    let search = new URLSearchParams();
    search.set('Madhav','moo');
    search.set('limit','25');
    //this.http.get(this.apiroot + this.getdata).subscribe(res => console.log(res.text()));
    this.http.put(this.apiroot + this.putdata, this.requestOptions).subscribe(res => console.log(res.json()));


  }

  doDELETE(){

    let search = new URLSearchParams();
    search.set('Madhav','moo');
    search.set('limit','25');
    //this.http.get(this.apiroot + this.getdata).subscribe(res => console.log(res.text()));
    this.http.delete(this.apiroot + this.deldata, this.requestOptions).subscribe(res => console.log(res.json()));

  }
  ngOnInit() {
  }

}
