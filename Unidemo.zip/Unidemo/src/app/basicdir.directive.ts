import { Directive } from '@angular/core';
import { ElementRef, OnInit } from '@angular/core';

@Directive({
  selector: '[appBasicdir]'
})
export class BasicdirDirective implements OnInit {

  constructor(private el:ElementRef) { }

  ngOnInit(){
    this.el.nativeElement.style.backgroundColor = "green";
  }
}
