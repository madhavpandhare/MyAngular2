import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
    MatButtonModule,
    MatToolbarModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatCardModule,
    MatTabsModule,
    MatMenuModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatDividerModule,
    MatListModule,
    MatSnackBarModule,
    MatPaginatorModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSidenavModule,
    MatIconModule,
    MatTableModule,
    MatGridListModule,
    MatStepperModule,
    MatAutocompleteModule,
    MatDialogModule
} from '@angular/material'

@NgModule({
    imports: [MatButtonModule,
        MatToolbarModule,
        MatInputModule,
        MatProgressSpinnerModule,
        MatCardModule,
        MatTabsModule,
        MatMenuModule,
        MatSliderModule,
        MatSlideToggleModule,
        MatDividerModule,
        MatListModule,
        MatSnackBarModule,
        MatPaginatorModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatSidenavModule,
        MatIconModule,
        MatTableModule,
        MatGridListModule,
        MatStepperModule,
        MatAutocompleteModule,
        MatDialogModule

    ],
    exports: [
        MatButtonModule,
        MatToolbarModule,
        MatInputModule,
        MatProgressSpinnerModule,
        MatCardModule,
        MatTabsModule,
        MatMenuModule,
        MatSliderModule,
        MatSlideToggleModule,
        MatDividerModule,
        MatListModule,
        MatSnackBarModule,
        MatPaginatorModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatSidenavModule,
        MatIconModule,
        MatTableModule,
        MatGridListModule,
        MatStepperModule,
        MatAutocompleteModule,
        MatDialogModule
    ]

})

export class MaterialModule {

}