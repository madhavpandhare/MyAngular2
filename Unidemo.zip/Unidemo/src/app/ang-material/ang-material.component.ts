import { Component, OnInit } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
import { MatIconRegistry } from '@angular/material';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-ang-material',
  templateUrl: './ang-material.component.html',
  styleUrls: ['./ang-material.component.css']
})
export class AngMaterialComponent implements OnInit {

  myData: any = [];
  answer: string = '';
  answerDisplay: string = '';
  showSpinner: boolean = false;
  showAnswer() {
    this.showSpinner = true;

    setTimeout(() => {
      this.answerDisplay = this.answer;
      this.showSpinner = false;
    }, 2000)
  }

  constructor(private http: HttpClient, iconRegistry: MatIconRegistry, sanitizer: DomSanitizer) {
    iconRegistry.addSvgIcon(
      'thumbs-up',
      sanitizer.bypassSecurityTrustResourceUrl('assets/ic_thumb_up_black_24px.svg'));

    this.http.get("https://jsonplaceholder.typicode.com/photos")
      .map(response => response)
      .subscribe(res => this.myData = res)
    console.log("hello" + this.myData);
  }

  ngOnInit() {
  }

}
