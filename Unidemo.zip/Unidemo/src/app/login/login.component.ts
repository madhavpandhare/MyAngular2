import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm, FormGroup, FormControl, Validators } from '@angular/forms';
//social button
import { AuthService, GoogleLoginProvider } from 'angular5-social-login';
import { HttpModule, Http } from '@angular/http';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  upusername;
  uppassword;

  constructor(private router:Router, private socialAuthService: AuthService) { }
  loginForm: FormGroup;

  public socialSignIn(socialplatform: string){
    let socialPlatformProvider;
    if(socialplatform == 'google'){
      socialPlatformProvider = GoogleLoginProvider.PROVIDER_ID;
    }

    this.socialAuthService.signIn(socialPlatformProvider).then(
    (userdata)=>{
       console.log(socialplatform+ " sign in data: " +userdata);
       this.router.navigate(['animatedata']);
    }
    );
  }

  ngOnInit() {

    this.loginForm = new FormGroup({
      'username': new FormControl( '', Validators.required ),
      'password': new FormControl('', [ Validators.required, Validators.minLength(8) ])
      
    })
    this.upusername = localStorage.getItem('username');
    this.uppassword = localStorage.getItem('password');
  }
  onsubmit(){
    
    localStorage.setItem('username',  this.loginForm.value.username);
    localStorage.setItem('password', this.loginForm.value.password);
    //this. username = localStorage.getItem('username');
    this.upusername = localStorage.getItem('username');
    this.uppassword = localStorage.getItem('password');
    this.router.navigate(['animatedata']);
    console.log("Clicked");
  }
}
