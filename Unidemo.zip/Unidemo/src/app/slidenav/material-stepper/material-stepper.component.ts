import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-material-stepper',
  templateUrl: './material-stepper.component.html',
  styleUrls: ['./material-stepper.component.css']
})
export class MaterialStepperComponent implements OnInit {

  isLinear = false;
  firstFormGroup : FormGroup;
  secondFormGroup : FormGroup;

  constructor(private formbuild:FormBuilder) { }

  ngOnInit() {
    this.firstFormGroup = this.formbuild.group({
      firstCtrl:['', Validators.required]

    });
    this.secondFormGroup = this.formbuild.group({
      secondCtrl : ['', Validators.required]
    })
  }

}
