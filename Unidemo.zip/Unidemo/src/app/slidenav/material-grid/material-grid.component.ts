import { Component, OnInit } from '@angular/core';
import {FormsModule} from '@angular/forms'

@Component({
  selector: 'app-material-grid',
  templateUrl: './material-grid.component.html',
  styleUrls: ['./material-grid.component.css']
})
export class MaterialGridComponent implements OnInit {

  constructor() { }
  quantity:any= {}

  grid: any = {colModel:[
    {hidden:true,  locked:false,label:'test'},
    {hidden:false, locked:true, label:'test1'}
  ]};

  check1= true;
  myDiv = true;
  getDiv(){
    if(this.check1 == true){
      this.myDiv = false;
      this.check1 = false;

    }else{
      this.myDiv = true;
      this.check1 = true;
    }
  }
  // grid1(){
  //   console.log("clicked");
  // }
  // grid2(){
  //   console.log("clicked");
  // }
  // grid3(){
  //   console.log("clicked");
  // }
  // grid4(){
  //   console.log("clicked");
  // }
  getData(){
    if(this.grid.colModel.length > 0) {
      this.grid.colModel[0].hidden = !this.grid.colModel[0].hidden;
    }
  }

  ngOnInit() {
  }

}
