import { Component, OnInit, ViewChild, Input } from '@angular/core';

@Component({
  selector: 'app-dialog-material',
  templateUrl: './dialog-material.component.html',
  styleUrls: ['./dialog-material.component.css']
})
export class DialogMaterialComponent implements OnInit {

  @ViewChild('myInputtext') inputtext;

  @Input() myValue;


  constructor() {
    setInterval(()=> {this.send2server();},2000);}

    send2server(){
      let data = this.inputtext.nativeElement;
      console.log(data.value);
    }


  public showForm = false;
  public hideme = true;
  public showTable = false;
  public updatedData = false;
  public updatedTable = false;

  getForm(){
    this.showForm = true;
    this.hideme = false;
  }

  getTable(){
    this.showTable = true;
  }
  EditData(){
    this.showTable = false;
    this.showForm = true;
    this.updatedData = false;
    this.updatedTable = false;
  }
  updateValues(){
    this.updatedTable = true;
  }

  ngOnInit() {
    console.log(this.myValue);
  }

}
