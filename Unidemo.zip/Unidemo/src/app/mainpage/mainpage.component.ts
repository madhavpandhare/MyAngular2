import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainpage',
  templateUrl: './mainpage.component.html',
  styleUrls: ['./mainpage.component.css']
})
export class MainpageComponent implements OnInit {

  itemCount : number = 4;
  btnText = "Hit me"
  Myvar = "my goal";
  Myarr = [];

  constructor() { }

  ngOnInit() {
    this.itemCount = this.Myarr.length;
  }
  addItem(){
    console.log("clicked");
    this.Myarr.push(this.Myvar);
    this.Myvar = '';
    this.itemCount = this.Myarr.length;
  }

}
