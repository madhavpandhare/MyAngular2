import { Component, OnInit, ElementRef } from '@angular/core';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {

  constructor( private myElement: ElementRef) { }

  ngOnInit() {
  }
  gotoAbout(){
    let el = this.myElement.nativeElement.getElementById('about_Content');
    el.scrollView();
    
  }
  onAbout(){
    let abt = document.querySelector('#about_Content');
    if(abt){
      abt.scrollIntoView();
    }
  }
  onHome(){
    let home = document.querySelector(".navbar-inverse");
    if(home){
      home.scrollIntoView();
    }

  }
  onPhoto(){
    let photo = document.querySelector("#photo_Content");
    if(photo){
      photo.scrollIntoView();
    }

  }
  onContact(){
    let con = document.querySelector("#about_Contact");
    if(con){
      con.scrollIntoView();
    }

  }
}
