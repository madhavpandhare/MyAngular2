import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { trigger, style, state, transition, animate, keyframes, query, stagger, } from '@angular/animations';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  animations: [
    trigger('backgroundAnimate',[
      state('animated',style({
        transform: 'translateX(80%) translateY(300px)',
      })),

    ])
  ]
})
export class HomeComponent implements OnInit {

  position:string = 'normal';

  constructor(private router:Router){}
  public hideme = true;
  linkto(){
    this.router.navigate(['index']);
    this.position = 'animated';
  }

  ngOnInit() {
  }
 

}
