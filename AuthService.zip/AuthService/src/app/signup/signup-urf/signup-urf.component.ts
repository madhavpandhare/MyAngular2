import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup-urf',
  templateUrl: './signup-urf.component.html',
  styleUrls: ['./signup-urf.component.css']
})
export class SignupURFComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
