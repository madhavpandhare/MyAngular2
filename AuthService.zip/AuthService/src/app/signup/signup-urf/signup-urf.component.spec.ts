import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SignupURFComponent } from './signup-urf.component';

describe('SignupURFComponent', () => {
  let component: SignupURFComponent;
  let fixture: ComponentFixture<SignupURFComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SignupURFComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SignupURFComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
