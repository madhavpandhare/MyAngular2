import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SignupRoutingModule } from './signup-routing.module';
import { SignupComponent } from './signup.component';
import { SignupUTDComponent } from './signup-utd/signup-utd.component';
import { SignupURFComponent } from './signup-urf/signup-urf.component';

@NgModule({
  declarations: [SignupComponent, SignupUTDComponent, SignupURFComponent],
  imports: [
    CommonModule,
    SignupRoutingModule
  ],
  exports:[SignupComponent,SignupURFComponent, SignupUTDComponent]
})
export class SignupModule { }
