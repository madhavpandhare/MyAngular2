import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SignupUTDComponent } from './signup-utd.component';

describe('SignupUTDComponent', () => {
  let component: SignupUTDComponent;
  let fixture: ComponentFixture<SignupUTDComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SignupUTDComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SignupUTDComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
