import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup-utd',
  templateUrl: './signup-utd.component.html',
  styleUrls: ['./signup-utd.component.css']
})
export class SignupUTDComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
