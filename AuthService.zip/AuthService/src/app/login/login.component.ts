import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../shared/service/user.service';
import { Users } from '../shared/interface/users';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  isExist: boolean = true;
  loginData:Users[];
  constructor(private router:Router,private userService:UserService) { }

  ngOnInit() {
    
  }

  login(frm){
    this.userService.isLogin().subscribe(
      (res) => {
        this.loginData = res;
        for(var i = 0; i < this.loginData.length; i++){
          if(frm.uname == this.loginData[i].uname && frm.upass == this.loginData[i].upass){
            sessionStorage.setItem('user',btoa(frm.uname));
            this.router.navigate(['/home']);
          }
          else{
            this.isExist = false;
          }
        }

      }
    )
    
  }
}
