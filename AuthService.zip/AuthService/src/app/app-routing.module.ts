import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { SignupComponent } from './signup/signup.component';
import { MenuComponent } from './menu/menu.component';
import { SignupURFComponent } from './signup/signup-urf/signup-urf.component';
import { SignupUTDComponent } from './signup/signup-utd/signup-utd.component';
import { AuthGuard } from './auth.guard';

const routes: Routes = [
  { path:'',    component:LoginComponent },
  { path:'home',  component:HomeComponent,canActivate:[AuthGuard]},
  { path:'signup', 
    component:SignupComponent, 
    children:[{path:'', redirectTo:'URF', pathMatch:'full'},{
      path:'URF',component:SignupURFComponent
  },{path:'UTD', component:SignupUTDComponent}],canActivate:[AuthGuard]},
  { path:'menu', component:MenuComponent,canActivate:[AuthGuard]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
