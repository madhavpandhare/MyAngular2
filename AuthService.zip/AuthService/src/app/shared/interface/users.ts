export interface Users {
    id:number;
    uname:string,
    upass: string
}