import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, CanActivate, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate  {
  canActivate(): boolean {
    if(!!sessionStorage.getItem('user')){
      return true;
    }
    else{
      alert('Access Denied');
      this.router.navigate(['/']);
      return false;
    }
  }
  constructor(private router:Router){}
  
}
