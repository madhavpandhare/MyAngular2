import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LazyloadingComponent } from './lazyloading.component';
import { Routes, RouterModule } from '@angular/router';

const Routes = [
  {
    path:'', component:LazyloadingComponent
  }
]

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(Routes)
  ],
  declarations: [LazyloadingComponent]
})
export class LazyloadingModule { }
