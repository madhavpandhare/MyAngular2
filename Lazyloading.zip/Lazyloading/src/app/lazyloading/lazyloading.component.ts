import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lazyloading',
  templateUrl: './lazyloading.component.html',
  styleUrls: ['./lazyloading.component.css']
})
export class LazyloadingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
