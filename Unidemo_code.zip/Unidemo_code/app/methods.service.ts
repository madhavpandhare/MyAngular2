import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class MethodsService {

  constructor( private http:HttpClient) { }


}
