import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormControl } from '@angular/forms';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-fileup',
  templateUrl: './fileup.component.html',
  styleUrls: ['./fileup.component.css']
})
export class FileupComponent implements OnInit {

  constructor(private httpClient:HttpClient) { }
	uploadForm = new FormGroup ({
		file1: new FormControl()
	});
	filedata:any;
	fileEvent(e){
		this.filedata = e.target.files[0];
		console.log(e);
	}
	onSubmit() {
		let formdata = new FormData();
		console.log(this.uploadForm)
		formdata.append("avatar",this.filedata);
		this.httpClient
		.post<any>("http://dlptest.com/http-post/",formdata)
		.subscribe((res)=> {console.log(res)});
	}

  ngOnInit() {
  }

}