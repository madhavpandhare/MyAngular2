import { Component, OnInit } from '@angular/core';
import { CartserviceService } from '../../services/cartservice.service';
//import {CartexampleComponent} from '../cartexample.component'
@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  public sumTotal;
  public TempTotal;
  public Subtotal;
  totalcart;
  constructor( private cartservice:CartserviceService) { }

  ngOnInit() {
    //this.sumTotal = this.cartservice.sumtotal;
    //console.log( this.totalcart);
    this.Subtotal = localStorage.getItem('temptot');
    this.TempTotal = localStorage.getItem('gettot');
    //console.log("Temp:" + this.TempTotal);
    //console.log("Subtot" + this.Subtotal);
    
    //sri code
      // this.cartservice.getmovie(list).then((sumtotal) => {
      // this.sumTotal = sumtotal;      
    //})  

    if(this.TempTotal === null || this.TempTotal === 0){
      this.sumTotal = localStorage.getItem('temptot');

    }else
    if(this.TempTotal < this.Subtotal){
      //console.log("Temp:"+this.TempTotal);
      this.sumTotal = localStorage.getItem('gettot');

    }else{
      //console.log("Subtot"+this.Subtotal);
      this.sumTotal = localStorage.getItem('temptot');
    }
    localStorage.removeItem('temptot');
    localStorage.removeItem('gettot');
  }

}
