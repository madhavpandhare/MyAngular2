import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartserviceService } from '../services/cartservice.service';

@Component({
  selector: 'app-cartexample',
  templateUrl: './cartexample.component.html',
  styleUrls: ['./cartexample.component.css']
})

export class CartexampleComponent implements OnInit {
  public n;
  public static  readonly MY_PUBLIC_CONSTANT = 10;
  public static x = 589;

  public xvar = CartexampleComponent.x;
  

  constructor(private router: Router, private cartservice: CartserviceService) { }
  ngOnInit() {
    
    const abc = 5;
    console.log(abc);
    //console.log(CartexampleComponent.MY_PUBLIC_CONSTANT);
    localStorage.removeItem('gettot');
    localStorage.removeItem('temptot');
    this.n = this.cartservice.name;
    console.log(this.n);
    this.sumtotal = this.cartservice.sumtotal;
    //console.log(this.sumtotal);
  }

  public MovieList = [
    { 'id': 1, 'name': 'Iron Man', 'price': 100 },
    { 'id': 2, 'name': 'Avengers', 'price': 150 },
    { 'id': 3, 'name': 'Infinity War', 'price': 250 }];
  public totalArray = [];
  public CartList = [];
  public i = 0;
  public moviename = 'movies';
  public InitialShow = true;
  public toggle = false;
  public deletetoggle = false
  public isvalid = false;
  public sumtotal;
  public lmn=5;
  public add;

  getMovieData(list) {
    //this.add  =(this.lmn) + (this.abc);

    this.toggle = true;
    this.isvalid = true;
    this.InitialShow = false;
    this.deletetoggle = false;
    this.CartList.push(list.name);
    this.totalArray.push(list.price);
    this.sumtotal = this.totalArray.reduce((a, b) => a + b, 0);

    localStorage.setItem('temptot', this.sumtotal);
    //localStorage.getItem('temptot');

    this.i += 1;
    if (this.i === 1) {
      this.moviename = 'movie';
    } else {
      this.moviename = 'movies';
    }

  }
  removeitem(ival) {
    this.CartList.splice(ival, 1);
    this.totalArray.splice(ival, 1);
    this.sumtotal = this.totalArray.reduce((a, b) => a + b, 0);
    localStorage.setItem('gettot', this.sumtotal);
    //localStorage.getItem('gettot');
    this.i -= 1;
    if (this.i === 1) {
      this.moviename = 'movie';
    } else {
      this.moviename = 'movies';
    }
    this.deletetoggle = true;
    this.toggle = false;
  }
  emortycart() {
    this.CartList = [];
    this.isvalid = false;
    this.InitialShow = true;
    this.toggle = false;
    this.deletetoggle = false;
    this.i = 0;
    this.sumtotal = 0;
    this.totalArray = [];
    localStorage.removeItem('gettot');
    localStorage.removeItem('temptot');
  }
  checkout() {

    if (this.i == 0) {
      this.isvalid = false;
    }
  }
  getcheck() {
    this.router.navigate(['/checkout']);
  }

}

