import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildmodalComponent } from './childmodal.component';

describe('ChildmodalComponent', () => {
  let component: ChildmodalComponent;
  let fixture: ComponentFixture<ChildmodalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChildmodalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChildmodalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
