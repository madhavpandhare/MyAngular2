import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { MaterialModule } from '../../material.module';
import { MaterialGridComponent } from '../material-grid/material-grid.component';
import {FormsModule} from '@angular/forms'

const Routes = [
  {
    path: '', 
    component: MaterialGridComponent
  }
]

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    RouterModule.forChild(Routes) ,
    FormsModule
  ],
  declarations: [MaterialGridComponent]
})
export class LazyloadingModule { }
