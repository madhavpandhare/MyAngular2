import { Component, OnInit } from '@angular/core';

import {FormControl} from '@angular/forms';


@Component({
  selector: 'app-autocomp-material',
  templateUrl: './autocomp-material.component.html',
  styleUrls: ['./autocomp-material.component.css']
})


export class AutocompMaterialComponent {
  stateCtrl: FormControl;
  enableonly = true;
  disabled;
  myControl: FormControl = new FormControl();

  constructor(){
    this.stateCtrl = new FormControl();
  }

  options = [
    'One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten'
  ];

  SearchData = [
    'Programmer', 'Developer', 'Engineer'
  ]
}
