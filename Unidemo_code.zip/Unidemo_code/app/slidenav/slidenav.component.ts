import { Component, OnInit, Sanitizer } from '@angular/core';
import { MatIconRegistry } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-slidenav',
  templateUrl: './slidenav.component.html',
  styleUrls: ['./slidenav.component.css']
})
export class SlidenavComponent implements OnInit {

  constructor(private iconreg:MatIconRegistry, private domsan:DomSanitizer) {
    iconreg.addSvgIcon(
      'hamburger',
      domsan.bypassSecurityTrustResourceUrl('assets/if_menu-alt_134216.svg')
    )
   }

  ngOnInit() { 
  }

}
