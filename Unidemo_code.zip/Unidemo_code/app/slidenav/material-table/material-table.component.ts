import { Component, OnInit } from '@angular/core';
import { UserService} from '../../services/user.service'
import{ Observable } from 'rxjs/observable'
import { DataSource } from '@angular/cdk/collections'
import { User } from '../../models/user.model'

@Component({
  selector: 'app-material-table',
  templateUrl: './material-table.component.html',
  styleUrls: ['./material-table.component.css']
})
export class MaterialTableComponent implements OnInit {

  dataSource = new UserdataSource(this.userService);
  displayedColumns = ['name', 'email','phone'];

  constructor(private userService:UserService) { }

  ngOnInit() {
  }
}

  export class UserdataSource extends DataSource<any>{
    constructor(private userService: UserService){
      super();

    }
    connect(): Observable<User[]>{
      return this.userService.getUser();

    }
    disconnect(){}
  }
