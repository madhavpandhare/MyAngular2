import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

//Forms imports
import { FormsModule, ReactiveFormsModule, FormControl, FormGroup } from '@angular/forms';
import { MainpageComponent } from './mainpage/mainpage.component';

import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';

import { AnimatedataComponent } from './animatedata/animatedata.component';
import { FileupComponent } from './fileup/fileup.component';

import { FileUploadModule } from 'primeng/fileupload';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MethodsService } from './methods.service';
import { PostuploadComponent } from './postupload/postupload.component';
import { Http, HttpModule } from '@angular/http';
import { BasicdirDirective } from './basicdir.directive';

//Social Login
import { SocialLoginModule, AuthServiceConfig, GoogleLoginProvider } from "angular5-social-login";
import { AngMaterialComponent } from './ang-material/ang-material.component'
//materail design
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { SidenavMaterialComponent } from './sidenav-material/sidenav-material.component'
import { MaterialModule } from './material.module'
import 'hammerjs';
import { SlidenavComponent } from './slidenav/slidenav.component';
import { MaterialTableComponent } from './slidenav/material-table/material-table.component';
//import { MaterialGridComponent } from './slidenav/material-grid/material-grid.component';
import { MaterialStepperComponent } from './slidenav/material-stepper/material-stepper.component';
import { UserService } from './services/user.service';
import { CommonService } from './services/common.service';
import { DateformatComponent } from './dateformat/dateformat.component';
import { AutocompMaterialComponent } from './slidenav/autocomp-material/autocomp-material.component';
import { ModaldataComponent } from './modaldata/modaldata.component';
import { DialogMaterialComponent } from './slidenav/dialog-material/dialog-material.component';
import { RoutingModule } from './routing.module';
import { AutologpageComponent } from './autolog/autologpage/autologpage.component';
import { AutologcontentComponent } from './autolog/autologcontent/autologcontent.component';
import { NgIdleModule } from '@ng-idle/core';
import { DragndropComponent } from './dragndrop/dragndrop.component';
import { DndModule } from 'ng2-dnd';
import { CartexampleComponent } from './cartexample/cartexample.component';
import { CheckoutComponent } from './cartexample/checkout/checkout.component';
import { SortPipe } from './dateformat/sort.pipe';
import { ChildmodalComponent } from './modaldata/childmodal/childmodal.component';
import { CartserviceService } from './services/cartservice.service';


const appRoutes = [
  {
    path: 'mainpage', component: MainpageComponent
  },
  {
    path: 'animatedata', component: AnimatedataComponent
  },
  {
    path: 'login', component: LoginComponent
  },
  {
    path: 'fileup', component: FileupComponent
  },
  {
    path: 'postupload', component: PostuploadComponent
  },
  {
    path: 'ang-material', component: AngMaterialComponent
  },
  {
    path: 'sidenav-material', component: SidenavMaterialComponent
  },
  {
    path: 'dateformat', component:DateformatComponent
  },
  {
    path: 'slidenav',
    component: SlidenavComponent,
    children: [
      {
        path: 'material-table', component: MaterialTableComponent
      },
      {
        path: 'material-grid', loadChildren: './slidenav/lazyloading/lazyloading.module#LazyloadingModule'
      },
      {
        path: 'material-stepper', component: MaterialStepperComponent
      },
      {
        path:'autocomp-material', component:AutocompMaterialComponent
      },
      {
        path: 'dialog-material', component:DialogMaterialComponent
      },
    ]

  },
  {
    path: 'modaldata', component:ModaldataComponent
  },
  {
    path:'autologpage', component:AutologpageComponent
  },
  {
    path:'autologcontent', component:AutologcontentComponent
  },
  {
    path:'dragndrop', component:DragndropComponent
  },
  {
    path:'cartexample', component:CartexampleComponent
  },
  {
    path:'checkout', component:CheckoutComponent
  },
  {
    path:'**', component:MainpageComponent
  }

]

//Config for social login

export function getAuthServiceConfigs() {
  let config = new AuthServiceConfig(
    [
      {
        id: GoogleLoginProvider.PROVIDER_ID,
        provider: new GoogleLoginProvider("393273471320-50gn8h32a64uubgt9jkf28o6s3mm2ri2.apps.googleusercontent.com")

      }
    ]
  );
  return config;
}

@NgModule({
  declarations: [
    AppComponent,
    MainpageComponent,
    LoginComponent,
    AnimatedataComponent,
    FileupComponent,
    PostuploadComponent,
    BasicdirDirective,
    FileupComponent,
    AngMaterialComponent,
    SidenavMaterialComponent,
    SlidenavComponent,
    MaterialTableComponent,
    
    MaterialStepperComponent,
    DateformatComponent,
    AutocompMaterialComponent,
    ModaldataComponent,
    DialogMaterialComponent,
    AutologpageComponent,
    AutologcontentComponent,
    DragndropComponent,
    CartexampleComponent,
    CheckoutComponent,
    SortPipe,
    ChildmodalComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes),
    NgIdleModule.forRoot(),
    DndModule.forRoot(),
    BrowserAnimationsModule,
    FileUploadModule,
    HttpClientModule,
    HttpModule,
    SocialLoginModule,
    MaterialModule,
    RoutingModule
  ],
  providers: [MethodsService,
    {
      provide: AuthServiceConfig,
      useFactory: getAuthServiceConfigs
    },
    UserService, CommonService, CartserviceService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
